# Iridescent morphing blob 

A Pen created on CodePen.io. Original URL: [https://codepen.io/lila1984/pen/zYBLVKb](https://codepen.io/lila1984/pen/zYBLVKb).

