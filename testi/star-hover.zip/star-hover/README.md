# STAR HOVER

A Pen created on CodePen.io. Original URL: [https://codepen.io/chasingafterdear/pen/yLmomBL](https://codepen.io/chasingafterdear/pen/yLmomBL).

